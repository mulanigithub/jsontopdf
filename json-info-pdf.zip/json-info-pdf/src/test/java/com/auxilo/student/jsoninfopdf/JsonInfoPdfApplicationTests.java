package com.auxilo.student.jsoninfopdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonInfoPdfApplicationTests {

	@Test
	void contextLoads() {
	}

}
