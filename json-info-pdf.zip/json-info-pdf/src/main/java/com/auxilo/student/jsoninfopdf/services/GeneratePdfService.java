package com.auxilo.student.jsoninfopdf.services;

import com.auxilo.student.jsoninfopdf.entity.Student;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Service
public class GeneratePdfService {

    public ResponseEntity<byte[]> generatePdfResponse(Student student) {
        try {
            byte[] pdfBytes = generatePdf(student);
            String filename = generateFilename(student);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDisposition(ContentDisposition.builder("attachment").filename(filename).build());

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(pdfBytes);
        } catch (IOException | DocumentException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    public byte[] generatePdf(Student student) throws IOException, DocumentException {
        Document document = new Document();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        // Create a PDF writer to write the document to a byte array output stream
        PdfWriter.getInstance(document, outputStream);

        document.open();

        // Add student information to the document
        addStudentInformation(document, student);

        document.close();

        return outputStream.toByteArray();
    }

    private void addStudentInformation(Document document, Student student) throws DocumentException {
        // Add student information to the document
        document.add(new Paragraph("Student Name: " + student.getName()));
        document.add(new Paragraph("Student ID: " + student.getId()));
        document.add(new Paragraph("Email: " + student.getEmail()));
        document.add(new Paragraph("PAN: " + student.getPan()));

        // You can add additional information or formatting as per your requirements
    }

    public String generateFilename(Student student) {
        String sanitizedId = sanitizeString(String.valueOf(student.getId()));
        String sanitizedName = sanitizeString(student.getName());

        return "student_" + sanitizedId + "_" + sanitizedName + ".pdf";
    }

    public void savePdfLocally(byte[] pdfBytes, String filename) throws IOException {
        String savePath = "C:\\Users\\FAISHAL KHAN\\Desktop\\mulani"; // Set the desired local path

        File directory = new File(savePath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        File file = new File(directory, filename);
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        fileOutputStream.write(pdfBytes);
        fileOutputStream.close();
    }

    private String sanitizeString(String input) {
        // Replace any characters that are not alphanumeric or underscores with an empty string
        return input.replaceAll("[^a-zA-Z0-9_]", "");
    }
}
