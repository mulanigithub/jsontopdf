package com.auxilo.student.jsoninfopdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonInfoPdfApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonInfoPdfApplication.class, args);
	}

}
