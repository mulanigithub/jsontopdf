package com.auxilo.student.jsoninfopdf.services;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.auxilo.student.jsoninfopdf.entity.Student;


@Service
public class StudentService {
    private Map<Long, Student> students = new ConcurrentHashMap<>();
    private AtomicLong idGenerator = new AtomicLong(0);

    public Student createStudent(Student student) {
        long newId = idGenerator.incrementAndGet();
        student.setId(newId);
        students.put(newId, student);
        return student;
    }

    public List<Student> getAllStudents() {
        return new ArrayList<>(students.values());
    }

    public Student getStudentById(long id) {
        return students.get(id);
    }

    public boolean updateStudent(Student updatedStudent) {
        long id = updatedStudent.getId();
        if (students.containsKey(id)) {
            students.put(id, updatedStudent);
            return true;
        }
        return false;
    }

    public boolean deleteStudent(long id) {
        if (students.containsKey(id)) {
            students.remove(id);
            return true;
        }
        return false;
    }

    public Student getStudentByPan(String pan) {
        return students.get(pan);
    }


    public boolean checkStudentExists(@Valid Student student) {
    for (Map.Entry<Long, Student> entry : students.entrySet()) {
        if (entry.getValue().getId().equals(student.getId())) {
            return true;
        }
    }
    return false;
}


    // Other methods for student operations in the service class
}



