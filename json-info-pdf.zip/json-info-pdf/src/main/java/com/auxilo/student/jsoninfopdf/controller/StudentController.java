package com.auxilo.student.jsoninfopdf.controller;

import com.auxilo.student.jsoninfopdf.entity.Student;
import com.auxilo.student.jsoninfopdf.services.GeneratePdfService;
import com.auxilo.student.jsoninfopdf.services.StudentService;
import com.itextpdf.text.DocumentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private GeneratePdfService generatePdfService;
    @PostMapping("/pdf")
    public ResponseEntity<byte[]> generatePdfForStudent(@RequestBody @Valid Student student) {
    try {
        if (student.getId() == null) {
            Student createdStudent = studentService.createStudent(student);
            student.setId(createdStudent.getId());
        } else {
            boolean updated = studentService.updateStudent(student);
            if (!updated) {
                return ResponseEntity.notFound().build();
            }
        }

        byte[] pdfBytes = generatePdfService.generatePdf(student);
        String filename = generatePdfService.generateFilename(student);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", filename);

        // Save the PDF file at a local path
        generatePdfService.savePdfLocally(pdfBytes, filename);

        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes);
    } catch (Exception e) {
        e.printStackTrace();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
}

    @GetMapping(value = "/pdf/{id}", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> generatePdfForStudent(@PathVariable("id") long id) {
        Student student = studentService.getStudentById(id);
        if (student != null) {
            try {
                byte[] pdfBytes = generatePdfService.generatePdf(student);
                String filename = generatePdfService.generateFilename(student);

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_PDF);
                headers.setContentDispositionFormData("attachment", filename);

                return ResponseEntity.ok()
                        .headers(headers)
                        .body(pdfBytes);
            } catch (IOException | DocumentException e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Student> createStudent(@RequestBody @Valid Student student) {
        Student createdStudent = studentService.createStudent(student);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdStudent);
    }

    @GetMapping
    public ResponseEntity<List<Student>> getAllStudents() {
        List<Student> students = studentService.getAllStudents();
        return ResponseEntity.ok(students);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable("id") long id) {
        Student student = studentService.getStudentById(id);
        if (student != null) {
            return ResponseEntity.ok(student);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable("id") long id, @RequestBody @Valid Student updatedStudent) {
        Student existingStudent = studentService.getStudentById(id);
        if (existingStudent != null) {
            updatedStudent.setId(id);
            boolean updated = studentService.updateStudent(updatedStudent);
            if (updated) {
                return ResponseEntity.ok(updatedStudent);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable("id") long id) {
        boolean deleted = studentService.deleteStudent(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
